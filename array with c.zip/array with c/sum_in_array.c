#include<stdio.h>
int main()
{
    int a[10];
    int i, avg=0, n;


    scanf("%d", &n);

    for(i=0; i<n; i++)
    scanf("%d", &a[i]);

    for(i=0; i<n; i++)
    {
        avg = avg + a[i];


    }
    printf("Summation is :%d\n", avg);

    return 0;
}
