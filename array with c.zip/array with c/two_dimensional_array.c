#include<stdio.h>
int main(){
    int stdnt[4][2];
    int i,j;
    for(i=0;i<=3;i++){
        printf("Enter your roll number and marks :");
        scanf("%d %d", &stdnt[i][0],&stdnt[i][1]);
    }
    for(i=0;i<=3;i++)
        printf("%d %d", &stdnt[i][0],&stdnt[i][1]);

    return 0;
}
