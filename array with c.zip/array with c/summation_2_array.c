#include<stdio.h>
int main(){
    int num[10], i, sum = 0;

    printf("Enter ten number :");
    for(i=0; i<=9; i++){
        scanf("%d", &num[i]);
    }
        for(i=0; i<=9; i++)
        sum = sum + num[i];
        printf("Summation is :%d\n" ,sum);

    return 0;
}
