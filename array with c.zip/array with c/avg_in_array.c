#include<stdio.h>
int main()
{
    int a[10];
    int i, sum=0, n;
    float avg;

    scanf("%d", &n);

    for(i=0; i<n; i++)
    scanf("%d", &a[i]);

    for(i=0; i<n; i++)
    {
        sum = sum + a[i];
    }

    avg = (float)sum/n;
    printf("Average number in array :%0.2f\n", avg);

    return 0;
}
