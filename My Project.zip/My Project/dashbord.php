<?php include 'db.php';?>
<?php include 'auth.php';?>
<!DOCTYPE html>
<html>
<head>
	<title>Desboard</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div class="welcome">
	<h1>Welcome to Dashboard..</h1>
	<h2>This is another secure page</h2>
	<a href="index.php">Home</a>
	<a href="logout.php">Logout</a>
</div>
</body>
</html>