<?php include 'auth.php';?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<div class="welcome">
	<h1>Welcome to our Website..</h1>
	<a href="dashbord.php">Dashboard</a>
	<a href="logout.php">Logout</a>
</div>
</body>
</html>